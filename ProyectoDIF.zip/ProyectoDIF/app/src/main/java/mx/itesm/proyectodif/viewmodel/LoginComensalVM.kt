package mx.itesm.proyectodif.viewmodel

import androidx.lifecycle.ViewModel

class LoginComensalVM : ViewModel() {
    // TODO: Implement the ViewModel
}