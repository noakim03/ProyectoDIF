package mx.itesm.proyectodif

import androidx.lifecycle.ViewModel

class CalificarServicioVM : ViewModel() {
    // TODO: Implement the ViewModel
}