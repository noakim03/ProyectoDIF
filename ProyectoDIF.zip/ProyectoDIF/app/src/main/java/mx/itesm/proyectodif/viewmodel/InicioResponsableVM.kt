package mx.itesm.proyectodif.viewmodel

import androidx.lifecycle.ViewModel

class InicioResponsableVM : ViewModel() {
    // TODO: Implement the ViewModel
}