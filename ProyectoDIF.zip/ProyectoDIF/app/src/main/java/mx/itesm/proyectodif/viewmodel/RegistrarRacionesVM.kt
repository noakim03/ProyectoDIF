package mx.itesm.proyectodif.viewmodel

import androidx.lifecycle.ViewModel

class RegistrarRacionesVM : ViewModel() {
    // TODO: Implement the ViewModel
}