package mx.itesm.proyectodif

import androidx.lifecycle.ViewModel

class RacionesRegistradoVM : ViewModel() {
    // TODO: Implement the ViewModel
}