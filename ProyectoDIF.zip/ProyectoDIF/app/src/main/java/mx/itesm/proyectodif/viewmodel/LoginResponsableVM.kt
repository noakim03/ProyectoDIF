package mx.itesm.proyectodif.viewmodel

import androidx.lifecycle.ViewModel

class LoginResponsableVM : ViewModel() {
    // TODO: Implement the ViewModel
}