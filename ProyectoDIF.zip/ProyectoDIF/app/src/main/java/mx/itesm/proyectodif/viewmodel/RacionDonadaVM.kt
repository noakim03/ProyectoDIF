package mx.itesm.proyectodif.viewmodel

import androidx.lifecycle.ViewModel

class RacionDonadaVM : ViewModel() {
    // TODO: Implement the ViewModel
}